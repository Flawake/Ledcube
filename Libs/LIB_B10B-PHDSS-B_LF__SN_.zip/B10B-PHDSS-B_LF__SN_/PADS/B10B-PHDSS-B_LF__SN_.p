*PADS-LIBRARY-PART-TYPES-V9*

B10B-PHDSS-B_LF__SN_ B10BPHDSSBLFSN I CON 7 1 0 0 0
TIMESTAMP 2025.09.29.12.27.23
"Mouser Part Number" 306-B10BPHDSSBLFSN
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/JST-Commercial/B10B-PHDSS-BLFSN?qs=cdbOS8ANM9D7p4FtXr2JFQ%3D%3D
"Manufacturer_Name" JST (JAPAN SOLDERLESS TERMINALS)
"Manufacturer_Part_Number" B10B-PHDSS-B(LF)(SN)
"Description" Conn Shrouded Header HDR 10 POS 2mm Solder ST Thru-Hole Box
"Datasheet Link" https://www.jst-mfg.com/product/pdf/eng/ePHD.pdf?63da7049bef1e
"Geometry.Height" 6.5mm
GATE 1 10 0
B10B-PHDSS-B_LF__SN_
1 0 U 1
2 0 U 2
3 0 U 3
4 0 U 4
5 0 U 5
6 0 U 6
7 0 U 7
8 0 U 8
9 0 U 9
10 0 U 10

*END*
*REMARK* SamacSys ECAD Model
2397149/418059/2.50/10/3/Connector
